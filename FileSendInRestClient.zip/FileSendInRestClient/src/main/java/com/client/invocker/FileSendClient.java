package com.client.invocker;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import javax.mail.MessagingException;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMultipart;

import org.omg.CORBA.portable.RemarshalException;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;

public class FileSendClient {
	
//	private final static String END_POINT = "https://svt.s2.infosarioregistry-test.com";
//	private final static String RESOURCE = "/rcservices/registry/surgeonregistry/facility/4798/case-reportform/save";
//	private final static String FILE_UPLOAD_ROOT_URI = END_POINT+RESOURCE;

	private final static String FILE_UPLOAD_ROOT_URI = "http://localhost:8085/ContentHandlerWeb/resource/order/new/file";
	
	public static String doFileUpoload(String username, String password, String registerId, String facilityId,
			String fileAbsPath) throws FileNotFoundException, MessagingException {
		final ClientConfig config = new DefaultClientConfig();
		final Client client = Client.create(config);
		final WebResource resource = client.resource(FILE_UPLOAD_ROOT_URI)
				.queryParam("username", username)
				.queryParam("password", password)
				.queryParam("registerId", registerId)
				.queryParam("facilityId", facilityId);
		final MimeMultipart request = new MimeMultipart();
		request.addBodyPart(new MimeBodyPart(new FileInputStream(new File(fileAbsPath))));
		final String response = resource.entity(request, "multipart/form-data").accept("text/plain").post(String.class);
		System.out.println(response);
		return response;
	}

	public static void main(String[] args) {
		try {
			doFileUpoload(args[0], args[1], args[2], args[3], args[4]);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (MessagingException e) {
			e.printStackTrace();
		}
	}}
		/*String name=args[0];;
		String password=args[1];
		String regid="";
		String fid="";
		if(validateName(name)){
			System.out.println("valide User name : > "+name);
		}else{
			System.out.println("Plese enter valide User name");
		}
		if(validatePassword(password)){
			System.out.println("valide User name : > "+password);
		}else{
			System.out.println("Plese enter valide password");
			
		}
		if(validateRegisterId(RegisterId)){
		System.out.println("valide User name : > "+RegisterId");
		}else{
			System.out.println("Plese enter valide Register ");
			
		
		
		// try
		
		if(validatePassword(password)){
			System.out.println("valide User name : > "+password);
		}else{
			System.out.println("Plese enter valide password");
		}
		
	}
	public static boolean validateName( String name )
	   {
	      return name.matches( "[A-Z][a-zA-Z]*" );
	   }
	
	public static boolean validatePassword( String password )
	   {
	      return password.matches("((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20})");
	   }
	public static boolean validateRegd( String regid )
	   {
	      return regid.matches( "[A-Z][a-zA-Z]*" );
	   }
*/	
	

